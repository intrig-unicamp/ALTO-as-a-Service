package org.opendaylight.alto.ext.cli.fileconverter;

public class ConvertType {

    //TODO add more types

    public static final String NETWORK_MAP = "networkmap";

}
