package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.simple.impl.rev150512.modules.module.configuration;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.rev130405.modules.module.Configuration;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.simple.impl.rev150512.modules.module.configuration.simple.alto.adsal.impl.DataBroker;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;simple-alto-adsal-impl&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/simple-alto.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * case simple-alto-adsal-impl {
 *     container data-broker {
 *         leaf type {
 *             type leafref;
 *         }
 *         leaf name {
 *             type leafref;
 *         }
 *         uses service-ref {
 *             refine (urn:opendaylight:alto:simple-impl?revision=2015-05-12)type {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *             }
 *         }
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;simple-alto-adsal-impl/modules/module/configuration/(urn:opendaylight:alto:simple-impl?revision=2015-05-12)simple-alto-adsal-impl&lt;/i&gt;
 *
 */
public interface SimpleAltoAdsalImpl
    extends
    DataObject,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.simple.impl.rev150512.modules.module.configuration.SimpleAltoAdsalImpl>,
    Configuration
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto:simple-impl","2015-05-12","simple-alto-adsal-impl"));

    DataBroker getDataBroker();

}

