package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yangtools.yang.common.QName;
import java.util.List;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.cost.maps.CostMap;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * container cost-maps {
 *     list cost-map {
 *         key "resource-id"
 *         leaf resource-id {
 *             type resource-id;
 *         }
 *         leaf tag {
 *             type tag-string;
 *         }
 *         container meta {
 *             list dependent-vtags {
 *                 key "resource-id"
 *                 leaf resource-id {
 *                     type resource-id;
 *                 }
 *                 leaf tag {
 *                     type tag-string;
 *                 }
 *                 uses vtag;
 *             }
 *             container cost-type {
 *                 leaf cost-mode {
 *                     type cost-mode;
 *                 }
 *                 leaf cost-metric {
 *                     type cost-metric;
 *                 }
 *                 leaf description {
 *                     type string;
 *                 }
 *                 uses cost-type;
 *             }
 *             uses cost-map-meta;
 *         }
 *         list map {
 *             key "src"
 *             leaf src {
 *                 type pid-name;
 *             }
 *             list dst-costs {
 *                 key "dst"
 *                 leaf dst {
 *                     type pid-name;
 *                 }
 *                 leaf cost-default {
 *                     type string;
 *                 }
 *                 augment \(urn:opendaylight:alto)resources\(urn:opendaylight:alto)cost-maps\(urn:opendaylight:alto)cost-map\(urn:opendaylight:alto)map\(urn:opendaylight:alto)dst-costs {
 *                     status CURRENT;
 *                     leaf cost-default {
 *                         type string;
 *                     }
 *                 }
 *             }
 *         }
 *         uses cost-map;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service/resources/cost-maps&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMapsBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMapsBuilder
 *
 */
public interface CostMaps
    extends
    ChildOf<Resources>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto","2015-04-04","cost-maps"));

    List<CostMap> getCostMap();

}

