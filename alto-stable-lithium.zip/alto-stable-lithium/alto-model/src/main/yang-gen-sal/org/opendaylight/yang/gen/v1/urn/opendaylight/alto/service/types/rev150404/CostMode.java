package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404;


/**
 * The enumeration built-in type represents values from a set of assigned names.
 *
 */
public enum CostMode {
    /**
     * Numerical cost mode.
     *
     */
    Numerical(0),
    
    /**
     * Ordinal cost mode.
     *
     */
    Ordinal(1)
    ;


    int value;
    private static final java.util.Map<java.lang.Integer, CostMode> VALUE_MAP;

    static {
        final com.google.common.collect.ImmutableMap.Builder<java.lang.Integer, CostMode> b = com.google.common.collect.ImmutableMap.builder();
        for (CostMode enumItem : CostMode.values())
        {
            b.put(enumItem.value, enumItem);
        }

        VALUE_MAP = b.build();
    }

    private CostMode(int value) {
        this.value = value;
    }

    /**
     * @return integer value
     */
    public int getIntValue() {
        return value;
    }

    /**
     * @param valueArg
     * @return corresponding CostMode item
     */
    public static CostMode forValue(int valueArg) {
        return VALUE_MAP.get(valueArg);
    }
}
