package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404;
import org.opendaylight.yangtools.yang.binding.DataRoot;


/**
 * This module defines a data model for the ALTO services using restconf. Note this
 * is not interop with RFC7285.
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service&lt;/b&gt;
 * &lt;br&gt;Source path: &lt;i&gt;META-INF/yang/alto-service.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * module alto-service {
 *     yang-version 1;
 *     namespace "urn:opendaylight:alto";
 *     prefix "alto-restconf";
 *
 *     import alto-service-types { prefix "alto"; }
 *     revision 2015-04-04 {
 *         description "This module defines a data model for the ALTO services using restconf. Note this
 *                     is not interop with RFC7285.
 *         ";
 *     }
 *
 *     container resources {
 *         container IRD {
 *             container meta {
 *                 list cost-types {
 *                     key "cost-type-name"
 *                     leaf cost-type-name {
 *                         type cost-type-name;
 *                     }
 *                     leaf cost-mode {
 *                         type cost-mode;
 *                     }
 *                     leaf cost-metric {
 *                         type cost-metric;
 *                     }
 *                     leaf description {
 *                         type string;
 *                     }
 *                     uses cost-type;
 *                 }
 *                 container default-alto-network-map {
 *                     leaf resource-id {
 *                         type resource-id;
 *                     }
 *                 }
 *                 uses IRD-meta;
 *             }
 *             list resources {
 *                 key "resource-id"
 *                 leaf resource-id {
 *                     type resource-id;
 *                 }
 *                 leaf uri {
 *                     type uri;
 *                 }
 *                 leaf media-type {
 *                     type media-type;
 *                 }
 *                 leaf-list uses {
 *                     type resource-id;
 *                 }
 *                 leaf-list accepts {
 *                     type media-type;
 *                 }
 *                 container capabilities {
 *                     leaf cost-constraints {
 *                         type boolean;
 *                     }
 *                     leaf-list cost-type-names {
 *                         type cost-type-name;
 *                     }
 *                     leaf-list prop-types {
 *                         type endpoint-property-type;
 *                     }
 *                 }
 *                 uses uses;
 *                 uses accepts;
 *                 uses IRD-capabilities;
 *             }
 *             uses IRD;
 *         }
 *         container network-maps {
 *             list network-map {
 *                 key "resource-id"
 *                 leaf resource-id {
 *                     type resource-id;
 *                 }
 *                 leaf tag {
 *                     type tag-string;
 *                 }
 *                 list map {
 *                     key "pid"
 *                     leaf pid {
 *                         type pid-name;
 *                     }
 *                     list endpoint-address-group {
 *                         key "address-type"
 *                         leaf address-type {
 *                             type endpoint-address-type;
 *                         }
 *                         leaf-list endpoint-prefix {
 *                             type ip-prefix;
 *                         }
 *                     }
 *                     uses endpoint-address-group;
 *                 }
 *                 uses network-map;
 *             }
 *         }
 *         container cost-maps {
 *             list cost-map {
 *                 key "resource-id"
 *                 leaf resource-id {
 *                     type resource-id;
 *                 }
 *                 leaf tag {
 *                     type tag-string;
 *                 }
 *                 container meta {
 *                     list dependent-vtags {
 *                         key "resource-id"
 *                         leaf resource-id {
 *                             type resource-id;
 *                         }
 *                         leaf tag {
 *                             type tag-string;
 *                         }
 *                         uses vtag;
 *                     }
 *                     container cost-type {
 *                         leaf cost-mode {
 *                             type cost-mode;
 *                         }
 *                         leaf cost-metric {
 *                             type cost-metric;
 *                         }
 *                         leaf description {
 *                             type string;
 *                         }
 *                         uses cost-type;
 *                     }
 *                     uses cost-map-meta;
 *                 }
 *                 list map {
 *                     key "src"
 *                     leaf src {
 *                         type pid-name;
 *                     }
 *                     list dst-costs {
 *                         key "dst"
 *                         leaf dst {
 *                             type pid-name;
 *                         }
 *                         leaf cost-default {
 *                             type string;
 *                         }
 *                         augment \(urn:opendaylight:alto)resources\(urn:opendaylight:alto)cost-maps\(urn:opendaylight:alto)cost-map\(urn:opendaylight:alto)map\(urn:opendaylight:alto)dst-costs {
 *                             status CURRENT;
 *                             leaf cost-default {
 *                                 type string;
 *                             }
 *                         }
 *                     }
 *                 }
 *                 uses cost-map;
 *             }
 *         }
 *         container endpoint-property-map {
 *             container meta {
 *                 list dependent-vtags {
 *                     key "resource-id"
 *                     leaf resource-id {
 *                         type resource-id;
 *                     }
 *                     leaf tag {
 *                         type tag-string;
 *                     }
 *                     uses vtag;
 *                 }
 *                 uses endpoint-property-meta;
 *             }
 *             list endpoint-properties {
 *                 key "endpoint"
 *                 leaf endpoint {
 *                     type typed-endpoint-address;
 *                 }
 *                 list properties {
 *                     key "property-type"
 *                     leaf property-type {
 *                         type endpoint-property-type;
 *                     }
 *                     leaf property {
 *                         type endpoint-property-value;
 *                     }
 *                 }
 *             }
 *             uses endpoint-property-map;
 *         }
 *     }
 *
 *     grouping cost-map {
 *         leaf resource-id {
 *             type resource-id;
 *         }
 *         leaf tag {
 *             type tag-string;
 *         }
 *         container meta {
 *             list dependent-vtags {
 *                 key "resource-id"
 *                 leaf resource-id {
 *                     type resource-id;
 *                 }
 *                 leaf tag {
 *                     type tag-string;
 *                 }
 *                 uses vtag;
 *             }
 *             container cost-type {
 *                 leaf cost-mode {
 *                     type cost-mode;
 *                 }
 *                 leaf cost-metric {
 *                     type cost-metric;
 *                 }
 *                 leaf description {
 *                     type string;
 *                 }
 *                 uses cost-type;
 *             }
 *             uses cost-map-meta;
 *         }
 *         list map {
 *             key "src"
 *             leaf src {
 *                 type pid-name;
 *             }
 *             list dst-costs {
 *                 key "dst"
 *                 leaf dst {
 *                     type pid-name;
 *                 }
 *             }
 *         }
 *     }
 *     grouping network-map {
 *         leaf resource-id {
 *             type resource-id;
 *         }
 *         leaf tag {
 *             type tag-string;
 *         }
 *         list map {
 *             key "pid"
 *             leaf pid {
 *                 type pid-name;
 *             }
 *             list endpoint-address-group {
 *                 key "address-type"
 *                 leaf address-type {
 *                     type endpoint-address-type;
 *                 }
 *                 leaf-list endpoint-prefix {
 *                     type ip-prefix;
 *                 }
 *             }
 *             uses endpoint-address-group;
 *         }
 *     }
 *
 *     rpc endpoint-cost-service {
 *         input {
 *             container cost-type {
 *                 leaf cost-mode {
 *                     type cost-mode;
 *                 }
 *                 leaf cost-metric {
 *                     type cost-metric;
 *                 }
 *                 leaf description {
 *                     type string;
 *                 }
 *                 uses cost-type;
 *             }
 *             leaf-list constraints {
 *                 type constraint;
 *             }
 *             container endpoints {
 *                 leaf-list srcs {
 *                     type typed-endpoint-address;
 *                 }
 *                 leaf-list dsts {
 *                     type typed-endpoint-address;
 *                 }
 *             }
 *         }
 *         
 *         output {
 *             container endpoint-cost-service {
 *                 container meta {
 *                     container cost-type {
 *                         leaf cost-mode {
 *                             type cost-mode;
 *                         }
 *                         leaf cost-metric {
 *                             type cost-metric;
 *                         }
 *                         leaf description {
 *                             type string;
 *                         }
 *                         uses cost-type;
 *                     }
 *                 }
 *                 list endpoint-cost-map {
 *                     key "src"
 *                     leaf src {
 *                         type typed-endpoint-address;
 *                     }
 *                     list dst-costs {
 *                         key "dst"
 *                         leaf dst {
 *                             type typed-endpoint-address;
 *                         }
 *                         leaf cost-default {
 *                             type int32;
 *                         }
 *                         augment \(urn:opendaylight:alto)endpoint-cost-service\(urn:opendaylight:alto)output\(urn:opendaylight:alto)endpoint-cost-service\(urn:opendaylight:alto)endpoint-cost-map\(urn:opendaylight:alto)dst-costs {
 *                             status CURRENT;
 *                             leaf cost-default {
 *                                 type int32;
 *                             }
 *                         }
 *                     }
 *                 }
 *             }
 *         }
 *         status CURRENT;
 *     }
 *     rpc filtered-cost-map-service {
 *         input {
 *             leaf resource-id {
 *                 type resource-id;
 *             }
 *             container cost-type {
 *                 leaf cost-mode {
 *                     type cost-mode;
 *                 }
 *                 leaf cost-metric {
 *                     type cost-metric;
 *                 }
 *                 leaf description {
 *                     type string;
 *                 }
 *                 uses cost-type;
 *             }
 *             leaf-list constraints {
 *                 type constraint;
 *             }
 *             container pids {
 *                 leaf-list srcs {
 *                     type pid-name;
 *                 }
 *                 leaf-list dsts {
 *                     type pid-name;
 *                 }
 *             }
 *         }
 *         
 *         output {
 *             container filtered-cost-map-service {
 *                 leaf resource-id {
 *                     type resource-id;
 *                 }
 *                 leaf tag {
 *                     type tag-string;
 *                 }
 *                 container meta {
 *                     list dependent-vtags {
 *                         key "resource-id"
 *                         leaf resource-id {
 *                             type resource-id;
 *                         }
 *                         leaf tag {
 *                             type tag-string;
 *                         }
 *                         uses vtag;
 *                     }
 *                     container cost-type {
 *                         leaf cost-mode {
 *                             type cost-mode;
 *                         }
 *                         leaf cost-metric {
 *                             type cost-metric;
 *                         }
 *                         leaf description {
 *                             type string;
 *                         }
 *                         uses cost-type;
 *                     }
 *                     uses cost-map-meta;
 *                 }
 *                 list map {
 *                     key "src"
 *                     leaf src {
 *                         type pid-name;
 *                     }
 *                     list dst-costs {
 *                         key "dst"
 *                         leaf dst {
 *                             type pid-name;
 *                         }
 *                     }
 *                 }
 *                 uses cost-map;
 *             }
 *         }
 *         status CURRENT;
 *     }
 *     rpc filtered-network-map-service {
 *         input {
 *             leaf resource-id {
 *                 type resource-id;
 *             }
 *             leaf-list pids {
 *                 type pid-name;
 *             }
 *             leaf-list address-types {
 *                 type endpoint-address-type;
 *             }
 *         }
 *         
 *         output {
 *             container filtered-network-map-service {
 *                 leaf resource-id {
 *                     type resource-id;
 *                 }
 *                 leaf tag {
 *                     type tag-string;
 *                 }
 *                 list map {
 *                     key "pid"
 *                     leaf pid {
 *                         type pid-name;
 *                     }
 *                     list endpoint-address-group {
 *                         key "address-type"
 *                         leaf address-type {
 *                             type endpoint-address-type;
 *                         }
 *                         leaf-list endpoint-prefix {
 *                             type ip-prefix;
 *                         }
 *                     }
 *                     uses endpoint-address-group;
 *                 }
 *                 uses network-map;
 *             }
 *         }
 *         status CURRENT;
 *     }
 * }
 * &lt;/pre&gt;
 *
 */
public interface AltoServiceData
    extends
    DataRoot
{




    Resources getResources();

}

