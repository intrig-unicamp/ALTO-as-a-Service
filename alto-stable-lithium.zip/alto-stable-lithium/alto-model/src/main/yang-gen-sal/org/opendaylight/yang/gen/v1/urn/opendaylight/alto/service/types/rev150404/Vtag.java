package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yangtools.yang.common.QName;


/**
 * Version tag. Both resource-id and tag must be equal byte-for-byte. RFC7285 Sec. 
 * 10.3. object { ResourceID resource-id; JSONString tag; } VersionTag;
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service-types&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service-types.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping vtag {
 *     leaf resource-id {
 *         type resource-id;
 *     }
 *     leaf tag {
 *         type tag-string;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service-types/vtag&lt;/i&gt;
 *
 */
public interface Vtag
    extends
    DataObject
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto-service-types","2015-04-04","vtag"));

    ResourceId getResourceId();
    
    TagString getTag();

}

