package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.input;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.PidName;
import org.opendaylight.yangtools.yang.common.QName;
import java.util.List;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.FilteredCostMapServiceInput;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * container pids {
 *     leaf-list srcs {
 *         type pid-name;
 *     }
 *     leaf-list dsts {
 *         type pid-name;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service/filtered-cost-map-service/input/pids&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.input.PidsBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.input.PidsBuilder
 *
 */
public interface Pids
    extends
    ChildOf<FilteredCostMapServiceInput>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.input.Pids>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto","2015-04-04","pids"));

    List<PidName> getSrcs();
    
    List<PidName> getDsts();

}

