package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.network.map.service.output.FilteredNetworkMapService;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * container output {
 *     container filtered-network-map-service {
 *         leaf resource-id {
 *             type resource-id;
 *         }
 *         leaf tag {
 *             type tag-string;
 *         }
 *         list map {
 *             key "pid"
 *             leaf pid {
 *                 type pid-name;
 *             }
 *             list endpoint-address-group {
 *                 key "address-type"
 *                 leaf address-type {
 *                     type endpoint-address-type;
 *                 }
 *                 leaf-list endpoint-prefix {
 *                     type ip-prefix;
 *                 }
 *             }
 *             uses endpoint-address-group;
 *         }
 *         uses network-map;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service/filtered-network-map-service/output&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.FilteredNetworkMapServiceOutputBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.FilteredNetworkMapServiceOutputBuilder
 *
 */
public interface FilteredNetworkMapServiceOutput
    extends
    DataObject,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.FilteredNetworkMapServiceOutput>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto","2015-04-04","output"));

    FilteredNetworkMapService getFilteredNetworkMapService();

}

