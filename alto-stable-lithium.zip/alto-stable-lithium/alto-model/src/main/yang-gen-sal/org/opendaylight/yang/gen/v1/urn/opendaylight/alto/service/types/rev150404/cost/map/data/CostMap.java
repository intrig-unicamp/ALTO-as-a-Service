package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.cost.map.data;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.CostMapData;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.cost.map.data.cost.map.DstCosts;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.PidName;
import org.opendaylight.yangtools.yang.common.QName;
import java.util.List;
import org.opendaylight.yangtools.yang.binding.Augmentable;
import org.opendaylight.yangtools.yang.binding.Identifiable;


/**
 * The list represents the outer part of the cost matrix.CostMapData. RFC7285 Sec. 
 * 11.2.3.6. object-map { PIDName -&gt; DstCosts; } CostMapData;
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service-types&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service-types.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * list cost-map {
 *     key "src"
 *     leaf src {
 *         type pid-name;
 *     }
 *     list dst-costs {
 *         key "dst"
 *         leaf dst {
 *             type pid-name;
 *         }
 *         anyxml cost;
 *         uses alto-cost;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service-types/cost-map-data/cost-map&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.cost.map.data.CostMapBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.cost.map.data.CostMapBuilder
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.cost.map.data.CostMapKey
 *
 */
public interface CostMap
    extends
    ChildOf<CostMapData>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.cost.map.data.CostMap>,
    Identifiable<CostMapKey>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto-service-types","2015-04-04","cost-map"));

    /**
     * Source PID.
     *
     */
    PidName getSrc();
    
    /**
     * The list represents the inner part of the cost matrix.DstCosts. RFC7285 Sec. 
     * 11.2.3.6. object-map { PIDName -&gt; JSONValue; } DstCosts;
     *
     */
    List<DstCosts> getDstCosts();
    
    /**
     * Returns Primary Key of Yang List Type
     *
     */
    CostMapKey getKey();

}

