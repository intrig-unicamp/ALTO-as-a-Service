package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yangtools.concepts.Builder;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts1} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts1
 *
 */
public class DstCosts1Builder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts1> {

    private java.lang.Integer _costDefault;


    public DstCosts1Builder() {
    }

    public DstCosts1Builder(DstCosts1 base) {
        this._costDefault = base.getCostDefault();
    }


    public java.lang.Integer getCostDefault() {
        return _costDefault;
    }

    public DstCosts1Builder setCostDefault(java.lang.Integer value) {
        this._costDefault = value;
        return this;
    }

    public DstCosts1 build() {
        return new DstCosts1Impl(this);
    }

    private static final class DstCosts1Impl implements DstCosts1 {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts1> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts1.class;
        }

        private final java.lang.Integer _costDefault;


        private DstCosts1Impl(DstCosts1Builder base) {
            this._costDefault = base.getCostDefault();
        }

        @Override
        public java.lang.Integer getCostDefault() {
            return _costDefault;
        }

        private int hash = 0;
        private volatile boolean hashValid = false;
        
        @Override
        public int hashCode() {
            if (hashValid) {
                return hash;
            }
        
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_costDefault == null) ? 0 : _costDefault.hashCode());
        
            hash = result;
            hashValid = true;
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts1.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts1 other = (org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts1)obj;
            if (_costDefault == null) {
                if (other.getCostDefault() != null) {
                    return false;
                }
            } else if(!_costDefault.equals(other.getCostDefault())) {
                return false;
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("DstCosts1 [");
            boolean first = true;
        
            if (_costDefault != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_costDefault=");
                builder.append(_costDefault);
             }
            return builder.append(']').toString();
        }
    }

}
