package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yangtools.yang.common.QName;
import java.util.List;


/**
 * EndpointAddrGroup. RFC7285 Sec. 10.4.5. object-map { AddressType -&gt; 
 * endpoint-prefix&lt;0..*&gt;; } EndpointAddrGroup;
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service-types&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service-types.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping endpoint-address-group {
 *     list endpoint-address-group {
 *         key "address-type"
 *         leaf address-type {
 *             type endpoint-address-type;
 *         }
 *         leaf-list endpoint-prefix {
 *             type ip-prefix;
 *         }
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service-types/endpoint-address-group&lt;/i&gt;
 *
 */
public interface EndpointAddressGroup
    extends
    DataObject
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto-service-types","2015-04-04","endpoint-address-group"));

    List<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.address.group.EndpointAddressGroup> getEndpointAddressGroup();

}

