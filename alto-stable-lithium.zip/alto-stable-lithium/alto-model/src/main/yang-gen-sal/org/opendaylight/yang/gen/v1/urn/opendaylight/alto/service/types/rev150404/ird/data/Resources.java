package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ird.data;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.Uses;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ResourceId;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.IRDData;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.IRDCapabilities;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.MediaType;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.Accepts;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev100924.Uri;
import org.opendaylight.yangtools.yang.binding.Augmentable;
import org.opendaylight.yangtools.yang.binding.Identifiable;


/**
 * IRDResourceEntry. RFC7285 9.2.2. object { JSONString uri; JSONString media-type;
 * [JSONString accepts;] [Capabilities capabilities;] [ResourceID uses&lt;0..*&gt;;] } 
 * IRDResourceEntry;IRDResourceEntries. RFC7285 9.2.2. object-map { ResourceID -&gt; 
 * IRDResourceEntry; } IRDResourceEntries;InformationResourceDirectory. RFC7285 
 * 9.2.2. object { IRDResourceEntries resources; } InfoResourceDirectory : 
 * ResponseEntityBase;
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service-types&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service-types.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * list resources {
 *     key "resource-id"
 *     leaf resource-id {
 *         type resource-id;
 *     }
 *     leaf uri {
 *         type uri;
 *     }
 *     leaf media-type {
 *         type media-type;
 *     }
 *     leaf-list uses {
 *         type resource-id;
 *     }
 *     leaf-list accepts {
 *         type media-type;
 *     }
 *     container capabilities {
 *         leaf cost-constraints {
 *             type boolean;
 *         }
 *         leaf-list cost-type-names {
 *             type cost-type-name;
 *         }
 *         leaf-list prop-types {
 *             type endpoint-property-type;
 *         }
 *     }
 *     uses uses;
 *     uses accepts;
 *     uses IRD-capabilities;
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service-types/IRD-data/resources&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ird.data.ResourcesBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ird.data.ResourcesBuilder
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ird.data.ResourcesKey
 *
 */
public interface Resources
    extends
    ChildOf<IRDData>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ird.data.Resources>,
    Uses,
    Accepts,
    IRDCapabilities,
    Identifiable<ResourcesKey>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto-service-types","2015-04-04","resources"));

    ResourceId getResourceId();
    
    Uri getUri();
    
    MediaType getMediaType();
    
    /**
     * Returns Primary Key of Yang List Type
     *
     */
    ResourcesKey getKey();

}

