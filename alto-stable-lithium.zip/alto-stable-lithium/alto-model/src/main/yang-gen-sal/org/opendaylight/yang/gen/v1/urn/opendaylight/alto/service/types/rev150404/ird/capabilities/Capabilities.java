package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ird.capabilities;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.IRDCapabilities;
import java.util.List;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.EndpointPropertyType;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.CostTypeName;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service-types&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service-types.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * container capabilities {
 *     leaf cost-constraints {
 *         type boolean;
 *     }
 *     leaf-list cost-type-names {
 *         type cost-type-name;
 *     }
 *     leaf-list prop-types {
 *         type endpoint-property-type;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service-types/IRD-capabilities/capabilities&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ird.capabilities.CapabilitiesBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ird.capabilities.CapabilitiesBuilder
 *
 */
public interface Capabilities
    extends
    ChildOf<IRDCapabilities>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ird.capabilities.Capabilities>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto-service-types","2015-04-04","capabilities"));

    java.lang.Boolean isCostConstraints();
    
    List<CostTypeName> getCostTypeNames();
    
    List<EndpointPropertyType> getPropTypes();

}

