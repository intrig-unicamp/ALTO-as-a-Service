package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources;
import org.opendaylight.yangtools.yang.binding.Augmentation;
import org.opendaylight.yangtools.yang.binding.AugmentationHolder;
import org.opendaylight.yangtools.yang.binding.DataObject;
import java.util.HashMap;
import org.opendaylight.yangtools.concepts.Builder;
import java.util.List;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.cost.maps.CostMap;
import java.util.Collections;
import java.util.Map;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps
 *
 */
public class CostMapsBuilder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps> {

    private List<CostMap> _costMap;

    Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>> augmentation = Collections.emptyMap();

    public CostMapsBuilder() {
    }

    public CostMapsBuilder(CostMaps base) {
        this._costMap = base.getCostMap();
        if (base instanceof CostMapsImpl) {
            CostMapsImpl impl = (CostMapsImpl) base;
            if (!impl.augmentation.isEmpty()) {
                this.augmentation = new HashMap<>(impl.augmentation);
            }
        } else if (base instanceof AugmentationHolder) {
            @SuppressWarnings("unchecked")
            AugmentationHolder<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps> casted =(AugmentationHolder<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>) base;
            if (!casted.augmentations().isEmpty()) {
                this.augmentation = new HashMap<>(casted.augmentations());
            }
        }
    }


    public List<CostMap> getCostMap() {
        return _costMap;
    }
    
    @SuppressWarnings("unchecked")
    public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>> E getAugmentation(java.lang.Class<E> augmentationType) {
        if (augmentationType == null) {
            throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
        }
        return (E) augmentation.get(augmentationType);
    }

    public CostMapsBuilder setCostMap(List<CostMap> value) {
        this._costMap = value;
        return this;
    }
    
    public CostMapsBuilder addAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>> augmentationType, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps> augmentation) {
        if (augmentation == null) {
            return removeAugmentation(augmentationType);
        }
    
        if (!(this.augmentation instanceof HashMap)) {
            this.augmentation = new HashMap<>();
        }
    
        this.augmentation.put(augmentationType, augmentation);
        return this;
    }
    
    public CostMapsBuilder removeAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>> augmentationType) {
        if (this.augmentation instanceof HashMap) {
            this.augmentation.remove(augmentationType);
        }
        return this;
    }

    public CostMaps build() {
        return new CostMapsImpl(this);
    }

    private static final class CostMapsImpl implements CostMaps {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps.class;
        }

        private final List<CostMap> _costMap;

        private Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>> augmentation = Collections.emptyMap();

        private CostMapsImpl(CostMapsBuilder base) {
            this._costMap = base.getCostMap();
            switch (base.augmentation.size()) {
            case 0:
                this.augmentation = Collections.emptyMap();
                break;
            case 1:
                final Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>> e = base.augmentation.entrySet().iterator().next();
                this.augmentation = Collections.<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>>singletonMap(e.getKey(), e.getValue());
                break;
            default :
                this.augmentation = new HashMap<>(base.augmentation);
            }
        }

        @Override
        public List<CostMap> getCostMap() {
            return _costMap;
        }
        
        @SuppressWarnings("unchecked")
        @Override
        public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>> E getAugmentation(java.lang.Class<E> augmentationType) {
            if (augmentationType == null) {
                throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
            }
            return (E) augmentation.get(augmentationType);
        }

        private int hash = 0;
        private volatile boolean hashValid = false;
        
        @Override
        public int hashCode() {
            if (hashValid) {
                return hash;
            }
        
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_costMap == null) ? 0 : _costMap.hashCode());
            result = prime * result + ((augmentation == null) ? 0 : augmentation.hashCode());
        
            hash = result;
            hashValid = true;
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps other = (org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps)obj;
            if (_costMap == null) {
                if (other.getCostMap() != null) {
                    return false;
                }
            } else if(!_costMap.equals(other.getCostMap())) {
                return false;
            }
            if (getClass() == obj.getClass()) {
                // Simple case: we are comparing against self
                CostMapsImpl otherImpl = (CostMapsImpl) obj;
                if (augmentation == null) {
                    if (otherImpl.augmentation != null) {
                        return false;
                    }
                } else if(!augmentation.equals(otherImpl.augmentation)) {
                    return false;
                }
            } else {
                // Hard case: compare our augments with presence there...
                for (Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps>> e : augmentation.entrySet()) {
                    if (!e.getValue().equals(other.getAugmentation(e.getKey()))) {
                        return false;
                    }
                }
                // .. and give the other one the chance to do the same
                if (!obj.equals(this)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("CostMaps [");
            boolean first = true;
        
            if (_costMap != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_costMap=");
                builder.append(_costMap);
             }
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("augmentation=");
            builder.append(augmentation.values());
            return builder.append(']').toString();
        }
    }

}
