package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.cost.map.Meta;
import org.opendaylight.yangtools.yang.binding.AugmentationHolder;
import java.util.HashMap;
import org.opendaylight.yangtools.concepts.Builder;
import java.util.ArrayList;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.TagString;
import com.google.common.collect.Range;
import org.opendaylight.yangtools.yang.binding.Augmentation;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ResourceId;
import java.math.BigInteger;
import java.util.List;
import java.util.Collections;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.cost.map.Map;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService
 *
 */
public class FilteredCostMapServiceBuilder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService> {

    private List<Map> _map;
    private Meta _meta;
    private ResourceId _resourceId;
    private TagString _tag;
    private static void check_tagLength(final String value) {
        final int length = value.length();
        if (length >= 1 && length <= 64) {
            return;
        }
        throw new IllegalArgumentException(String.format("Invalid length: %s, expected: [[1‥64]].", value));
    }

    java.util.Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>> augmentation = Collections.emptyMap();

    public FilteredCostMapServiceBuilder() {
    }
    public FilteredCostMapServiceBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.CostMap arg) {
        this._resourceId = arg.getResourceId();
        this._tag = arg.getTag();
        this._meta = arg.getMeta();
        this._map = arg.getMap();
    }

    public FilteredCostMapServiceBuilder(FilteredCostMapService base) {
        this._map = base.getMap();
        this._meta = base.getMeta();
        this._resourceId = base.getResourceId();
        this._tag = base.getTag();
        if (base instanceof FilteredCostMapServiceImpl) {
            FilteredCostMapServiceImpl impl = (FilteredCostMapServiceImpl) base;
            if (!impl.augmentation.isEmpty()) {
                this.augmentation = new HashMap<>(impl.augmentation);
            }
        } else if (base instanceof AugmentationHolder) {
            @SuppressWarnings("unchecked")
            AugmentationHolder<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService> casted =(AugmentationHolder<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>) base;
            if (!casted.augmentations().isEmpty()) {
                this.augmentation = new HashMap<>(casted.augmentations());
            }
        }
    }

    /**
     *Set fields from given grouping argument. Valid argument is instance of one of following types:
     * <ul>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.CostMap</li>
     * </ul>
     *
     * @param arg grouping object
     * @throws IllegalArgumentException if given argument is none of valid types
    */
    public void fieldsFrom(DataObject arg) {
        boolean isValidArg = false;
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.CostMap) {
            this._resourceId = ((org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.CostMap)arg).getResourceId();
            this._tag = ((org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.CostMap)arg).getTag();
            this._meta = ((org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.CostMap)arg).getMeta();
            this._map = ((org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.CostMap)arg).getMap();
            isValidArg = true;
        }
        if (!isValidArg) {
            throw new IllegalArgumentException(
              "expected one of: [org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.CostMap] \n" +
              "but was: " + arg
            );
        }
    }

    public List<Map> getMap() {
        return _map;
    }
    
    public Meta getMeta() {
        return _meta;
    }
    
    public ResourceId getResourceId() {
        return _resourceId;
    }
    
    public TagString getTag() {
        return _tag;
    }
    
    @SuppressWarnings("unchecked")
    public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>> E getAugmentation(java.lang.Class<E> augmentationType) {
        if (augmentationType == null) {
            throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
        }
        return (E) augmentation.get(augmentationType);
    }

    public FilteredCostMapServiceBuilder setMap(List<Map> value) {
        this._map = value;
        return this;
    }
    
    public FilteredCostMapServiceBuilder setMeta(Meta value) {
        this._meta = value;
        return this;
    }
    
    public FilteredCostMapServiceBuilder setResourceId(ResourceId value) {
        if (value != null) {
        }
        this._resourceId = value;
        return this;
    }
    
    public FilteredCostMapServiceBuilder setTag(TagString value) {
        if (value != null) {
            check_tagLength(value.getValue());
        }
        this._tag = value;
        return this;
    }
    /**
     * @deprecated This method is slated for removal in a future release. See BUG-1485 for details.
     */
    @Deprecated
    public static List<Range<BigInteger>> _tag_length() {
        List<Range<BigInteger>> ret = new ArrayList<>(1);
        ret.add(Range.closed(BigInteger.ONE, BigInteger.valueOf(64L)));
        return ret;
    }
    
    public FilteredCostMapServiceBuilder addAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>> augmentationType, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService> augmentation) {
        if (augmentation == null) {
            return removeAugmentation(augmentationType);
        }
    
        if (!(this.augmentation instanceof HashMap)) {
            this.augmentation = new HashMap<>();
        }
    
        this.augmentation.put(augmentationType, augmentation);
        return this;
    }
    
    public FilteredCostMapServiceBuilder removeAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>> augmentationType) {
        if (this.augmentation instanceof HashMap) {
            this.augmentation.remove(augmentationType);
        }
        return this;
    }

    public FilteredCostMapService build() {
        return new FilteredCostMapServiceImpl(this);
    }

    private static final class FilteredCostMapServiceImpl implements FilteredCostMapService {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService.class;
        }

        private final List<Map> _map;
        private final Meta _meta;
        private final ResourceId _resourceId;
        private final TagString _tag;

        private java.util.Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>> augmentation = Collections.emptyMap();

        private FilteredCostMapServiceImpl(FilteredCostMapServiceBuilder base) {
            this._map = base.getMap();
            this._meta = base.getMeta();
            this._resourceId = base.getResourceId();
            this._tag = base.getTag();
            switch (base.augmentation.size()) {
            case 0:
                this.augmentation = Collections.emptyMap();
                break;
            case 1:
                final java.util.Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>> e = base.augmentation.entrySet().iterator().next();
                this.augmentation = Collections.<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>>singletonMap(e.getKey(), e.getValue());
                break;
            default :
                this.augmentation = new HashMap<>(base.augmentation);
            }
        }

        @Override
        public List<Map> getMap() {
            return _map;
        }
        
        @Override
        public Meta getMeta() {
            return _meta;
        }
        
        @Override
        public ResourceId getResourceId() {
            return _resourceId;
        }
        
        @Override
        public TagString getTag() {
            return _tag;
        }
        
        @SuppressWarnings("unchecked")
        @Override
        public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>> E getAugmentation(java.lang.Class<E> augmentationType) {
            if (augmentationType == null) {
                throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
            }
            return (E) augmentation.get(augmentationType);
        }

        private int hash = 0;
        private volatile boolean hashValid = false;
        
        @Override
        public int hashCode() {
            if (hashValid) {
                return hash;
            }
        
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_map == null) ? 0 : _map.hashCode());
            result = prime * result + ((_meta == null) ? 0 : _meta.hashCode());
            result = prime * result + ((_resourceId == null) ? 0 : _resourceId.hashCode());
            result = prime * result + ((_tag == null) ? 0 : _tag.hashCode());
            result = prime * result + ((augmentation == null) ? 0 : augmentation.hashCode());
        
            hash = result;
            hashValid = true;
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService other = (org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService)obj;
            if (_map == null) {
                if (other.getMap() != null) {
                    return false;
                }
            } else if(!_map.equals(other.getMap())) {
                return false;
            }
            if (_meta == null) {
                if (other.getMeta() != null) {
                    return false;
                }
            } else if(!_meta.equals(other.getMeta())) {
                return false;
            }
            if (_resourceId == null) {
                if (other.getResourceId() != null) {
                    return false;
                }
            } else if(!_resourceId.equals(other.getResourceId())) {
                return false;
            }
            if (_tag == null) {
                if (other.getTag() != null) {
                    return false;
                }
            } else if(!_tag.equals(other.getTag())) {
                return false;
            }
            if (getClass() == obj.getClass()) {
                // Simple case: we are comparing against self
                FilteredCostMapServiceImpl otherImpl = (FilteredCostMapServiceImpl) obj;
                if (augmentation == null) {
                    if (otherImpl.augmentation != null) {
                        return false;
                    }
                } else if(!augmentation.equals(otherImpl.augmentation)) {
                    return false;
                }
            } else {
                // Hard case: compare our augments with presence there...
                for (java.util.Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.output.FilteredCostMapService>> e : augmentation.entrySet()) {
                    if (!e.getValue().equals(other.getAugmentation(e.getKey()))) {
                        return false;
                    }
                }
                // .. and give the other one the chance to do the same
                if (!obj.equals(this)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("FilteredCostMapService [");
            boolean first = true;
        
            if (_map != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_map=");
                builder.append(_map);
             }
            if (_meta != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_meta=");
                builder.append(_meta);
             }
            if (_resourceId != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_resourceId=");
                builder.append(_resourceId);
             }
            if (_tag != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_tag=");
                builder.append(_tag);
             }
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("augmentation=");
            builder.append(augmentation.values());
            return builder.append(']').toString();
        }
    }

}
