package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404;
import org.opendaylight.yangtools.yang.binding.RpcService;
import org.opendaylight.yangtools.yang.common.RpcResult;
import java.util.concurrent.Future;


/**
 * Interface for implementing the following YANG RPCs defined in module &lt;b&gt;alto-service&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * rpc endpoint-cost-service {
 *     input {
 *         container cost-type {
 *             leaf cost-mode {
 *                 type cost-mode;
 *             }
 *             leaf cost-metric {
 *                 type cost-metric;
 *             }
 *             leaf description {
 *                 type string;
 *             }
 *             uses cost-type;
 *         }
 *         leaf-list constraints {
 *             type constraint;
 *         }
 *         container endpoints {
 *             leaf-list srcs {
 *                 type typed-endpoint-address;
 *             }
 *             leaf-list dsts {
 *                 type typed-endpoint-address;
 *             }
 *         }
 *     }
 *     
 *     output {
 *         container endpoint-cost-service {
 *             container meta {
 *                 container cost-type {
 *                     leaf cost-mode {
 *                         type cost-mode;
 *                     }
 *                     leaf cost-metric {
 *                         type cost-metric;
 *                     }
 *                     leaf description {
 *                         type string;
 *                     }
 *                     uses cost-type;
 *                 }
 *             }
 *             list endpoint-cost-map {
 *                 key "src"
 *                 leaf src {
 *                     type typed-endpoint-address;
 *                 }
 *                 list dst-costs {
 *                     key "dst"
 *                     leaf dst {
 *                         type typed-endpoint-address;
 *                     }
 *                     leaf cost-default {
 *                         type int32;
 *                     }
 *                     augment \(urn:opendaylight:alto)endpoint-cost-service\(urn:opendaylight:alto)output\(urn:opendaylight:alto)endpoint-cost-service\(urn:opendaylight:alto)endpoint-cost-map\(urn:opendaylight:alto)dst-costs {
 *                         status CURRENT;
 *                         leaf cost-default {
 *                             type int32;
 *                         }
 *                     }
 *                 }
 *             }
 *         }
 *     }
 *     status CURRENT;
 * }
 * rpc filtered-cost-map-service {
 *     input {
 *         leaf resource-id {
 *             type resource-id;
 *         }
 *         container cost-type {
 *             leaf cost-mode {
 *                 type cost-mode;
 *             }
 *             leaf cost-metric {
 *                 type cost-metric;
 *             }
 *             leaf description {
 *                 type string;
 *             }
 *             uses cost-type;
 *         }
 *         leaf-list constraints {
 *             type constraint;
 *         }
 *         container pids {
 *             leaf-list srcs {
 *                 type pid-name;
 *             }
 *             leaf-list dsts {
 *                 type pid-name;
 *             }
 *         }
 *     }
 *     
 *     output {
 *         container filtered-cost-map-service {
 *             leaf resource-id {
 *                 type resource-id;
 *             }
 *             leaf tag {
 *                 type tag-string;
 *             }
 *             container meta {
 *                 list dependent-vtags {
 *                     key "resource-id"
 *                     leaf resource-id {
 *                         type resource-id;
 *                     }
 *                     leaf tag {
 *                         type tag-string;
 *                     }
 *                     uses vtag;
 *                 }
 *                 container cost-type {
 *                     leaf cost-mode {
 *                         type cost-mode;
 *                     }
 *                     leaf cost-metric {
 *                         type cost-metric;
 *                     }
 *                     leaf description {
 *                         type string;
 *                     }
 *                     uses cost-type;
 *                 }
 *                 uses cost-map-meta;
 *             }
 *             list map {
 *                 key "src"
 *                 leaf src {
 *                     type pid-name;
 *                 }
 *                 list dst-costs {
 *                     key "dst"
 *                     leaf dst {
 *                         type pid-name;
 *                     }
 *                 }
 *             }
 *             uses cost-map;
 *         }
 *     }
 *     status CURRENT;
 * }
 * rpc filtered-network-map-service {
 *     input {
 *         leaf resource-id {
 *             type resource-id;
 *         }
 *         leaf-list pids {
 *             type pid-name;
 *         }
 *         leaf-list address-types {
 *             type endpoint-address-type;
 *         }
 *     }
 *     
 *     output {
 *         container filtered-network-map-service {
 *             leaf resource-id {
 *                 type resource-id;
 *             }
 *             leaf tag {
 *                 type tag-string;
 *             }
 *             list map {
 *                 key "pid"
 *                 leaf pid {
 *                     type pid-name;
 *                 }
 *                 list endpoint-address-group {
 *                     key "address-type"
 *                     leaf address-type {
 *                         type endpoint-address-type;
 *                     }
 *                     leaf-list endpoint-prefix {
 *                         type ip-prefix;
 *                     }
 *                 }
 *                 uses endpoint-address-group;
 *             }
 *             uses network-map;
 *         }
 *     }
 *     status CURRENT;
 * }
 * &lt;/pre&gt;
 *
 */
public interface AltoServiceService
    extends
    RpcService
{




    Future<RpcResult<EndpointCostServiceOutput>> endpointCostService(EndpointCostServiceInput input);
    
    Future<RpcResult<FilteredCostMapServiceOutput>> filteredCostMapService(FilteredCostMapServiceInput input);
    
    Future<RpcResult<FilteredNetworkMapServiceOutput>> filteredNetworkMapService(FilteredNetworkMapServiceInput input);

}

