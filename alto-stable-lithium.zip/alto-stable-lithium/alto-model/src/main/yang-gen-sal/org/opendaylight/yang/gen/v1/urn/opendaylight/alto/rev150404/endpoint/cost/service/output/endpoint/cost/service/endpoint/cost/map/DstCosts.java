package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.endpoint.cost.service.output.endpoint.cost.service.endpoint.cost.map;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.TypedEndpointAddress;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.Augmentable;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.endpoint.cost.service.output.endpoint.cost.service.EndpointCostMap;
import org.opendaylight.yangtools.yang.binding.Identifiable;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * list dst-costs {
 *     key "dst"
 *     leaf dst {
 *         type typed-endpoint-address;
 *     }
 *     leaf cost-default {
 *         type int32;
 *     }
 *     augment \(urn:opendaylight:alto)endpoint-cost-service\(urn:opendaylight:alto)output\(urn:opendaylight:alto)endpoint-cost-service\(urn:opendaylight:alto)endpoint-cost-map\(urn:opendaylight:alto)dst-costs {
 *         status CURRENT;
 *         leaf cost-default {
 *             type int32;
 *         }
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service/endpoint-cost-service/output/endpoint-cost-service/endpoint-cost-map/dst-costs&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.endpoint.cost.service.output.endpoint.cost.service.endpoint.cost.map.DstCostsBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.endpoint.cost.service.output.endpoint.cost.service.endpoint.cost.map.DstCostsBuilder
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.endpoint.cost.service.output.endpoint.cost.service.endpoint.cost.map.DstCostsKey
 *
 */
public interface DstCosts
    extends
    ChildOf<EndpointCostMap>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.endpoint.cost.service.output.endpoint.cost.service.endpoint.cost.map.DstCosts>,
    Identifiable<DstCostsKey>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto","2015-04-04","dst-costs"));

    TypedEndpointAddress getDst();
    
    /**
     * Returns Primary Key of Yang List Type
     *
     */
    DstCostsKey getKey();

}

