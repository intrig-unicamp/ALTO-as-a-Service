package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta;
import org.opendaylight.yangtools.yang.binding.AugmentationHolder;
import java.util.HashMap;
import org.opendaylight.yangtools.concepts.Builder;
import java.util.ArrayList;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.TagString;
import com.google.common.collect.Range;
import org.opendaylight.yangtools.yang.binding.Augmentation;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.ResourceId;
import java.math.BigInteger;
import java.util.List;
import java.util.Collections;
import java.util.Map;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag
 *
 */
public class VtagBuilder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag> {

    private ResourceId _resourceId;
    private TagString _tag;
    private static void check_tagLength(final String value) {
        final int length = value.length();
        if (length >= 1 && length <= 64) {
            return;
        }
        throw new IllegalArgumentException(String.format("Invalid length: %s, expected: [[1‥64]].", value));
    }

    Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>> augmentation = Collections.emptyMap();

    public VtagBuilder() {
    }
    public VtagBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.Vtag arg) {
        this._resourceId = arg.getResourceId();
        this._tag = arg.getTag();
    }

    public VtagBuilder(Vtag base) {
        this._resourceId = base.getResourceId();
        this._tag = base.getTag();
        if (base instanceof VtagImpl) {
            VtagImpl impl = (VtagImpl) base;
            if (!impl.augmentation.isEmpty()) {
                this.augmentation = new HashMap<>(impl.augmentation);
            }
        } else if (base instanceof AugmentationHolder) {
            @SuppressWarnings("unchecked")
            AugmentationHolder<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag> casted =(AugmentationHolder<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>) base;
            if (!casted.augmentations().isEmpty()) {
                this.augmentation = new HashMap<>(casted.augmentations());
            }
        }
    }

    /**
     *Set fields from given grouping argument. Valid argument is instance of one of following types:
     * <ul>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.Vtag</li>
     * </ul>
     *
     * @param arg grouping object
     * @throws IllegalArgumentException if given argument is none of valid types
    */
    public void fieldsFrom(DataObject arg) {
        boolean isValidArg = false;
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.Vtag) {
            this._resourceId = ((org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.Vtag)arg).getResourceId();
            this._tag = ((org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.Vtag)arg).getTag();
            isValidArg = true;
        }
        if (!isValidArg) {
            throw new IllegalArgumentException(
              "expected one of: [org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.Vtag] \n" +
              "but was: " + arg
            );
        }
    }

    public ResourceId getResourceId() {
        return _resourceId;
    }
    
    public TagString getTag() {
        return _tag;
    }
    
    @SuppressWarnings("unchecked")
    public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>> E getAugmentation(java.lang.Class<E> augmentationType) {
        if (augmentationType == null) {
            throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
        }
        return (E) augmentation.get(augmentationType);
    }

    public VtagBuilder setResourceId(ResourceId value) {
        if (value != null) {
        }
        this._resourceId = value;
        return this;
    }
    
    public VtagBuilder setTag(TagString value) {
        if (value != null) {
            check_tagLength(value.getValue());
        }
        this._tag = value;
        return this;
    }
    /**
     * @deprecated This method is slated for removal in a future release. See BUG-1485 for details.
     */
    @Deprecated
    public static List<Range<BigInteger>> _tag_length() {
        List<Range<BigInteger>> ret = new ArrayList<>(1);
        ret.add(Range.closed(BigInteger.ONE, BigInteger.valueOf(64L)));
        return ret;
    }
    
    public VtagBuilder addAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>> augmentationType, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag> augmentation) {
        if (augmentation == null) {
            return removeAugmentation(augmentationType);
        }
    
        if (!(this.augmentation instanceof HashMap)) {
            this.augmentation = new HashMap<>();
        }
    
        this.augmentation.put(augmentationType, augmentation);
        return this;
    }
    
    public VtagBuilder removeAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>> augmentationType) {
        if (this.augmentation instanceof HashMap) {
            this.augmentation.remove(augmentationType);
        }
        return this;
    }

    public Vtag build() {
        return new VtagImpl(this);
    }

    private static final class VtagImpl implements Vtag {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag.class;
        }

        private final ResourceId _resourceId;
        private final TagString _tag;

        private Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>> augmentation = Collections.emptyMap();

        private VtagImpl(VtagBuilder base) {
            this._resourceId = base.getResourceId();
            this._tag = base.getTag();
            switch (base.augmentation.size()) {
            case 0:
                this.augmentation = Collections.emptyMap();
                break;
            case 1:
                final Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>> e = base.augmentation.entrySet().iterator().next();
                this.augmentation = Collections.<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>>singletonMap(e.getKey(), e.getValue());
                break;
            default :
                this.augmentation = new HashMap<>(base.augmentation);
            }
        }

        @Override
        public ResourceId getResourceId() {
            return _resourceId;
        }
        
        @Override
        public TagString getTag() {
            return _tag;
        }
        
        @SuppressWarnings("unchecked")
        @Override
        public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>> E getAugmentation(java.lang.Class<E> augmentationType) {
            if (augmentationType == null) {
                throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
            }
            return (E) augmentation.get(augmentationType);
        }

        private int hash = 0;
        private volatile boolean hashValid = false;
        
        @Override
        public int hashCode() {
            if (hashValid) {
                return hash;
            }
        
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_resourceId == null) ? 0 : _resourceId.hashCode());
            result = prime * result + ((_tag == null) ? 0 : _tag.hashCode());
            result = prime * result + ((augmentation == null) ? 0 : augmentation.hashCode());
        
            hash = result;
            hashValid = true;
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag other = (org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag)obj;
            if (_resourceId == null) {
                if (other.getResourceId() != null) {
                    return false;
                }
            } else if(!_resourceId.equals(other.getResourceId())) {
                return false;
            }
            if (_tag == null) {
                if (other.getTag() != null) {
                    return false;
                }
            } else if(!_tag.equals(other.getTag())) {
                return false;
            }
            if (getClass() == obj.getClass()) {
                // Simple case: we are comparing against self
                VtagImpl otherImpl = (VtagImpl) obj;
                if (augmentation == null) {
                    if (otherImpl.augmentation != null) {
                        return false;
                    }
                } else if(!augmentation.equals(otherImpl.augmentation)) {
                    return false;
                }
            } else {
                // Hard case: compare our augments with presence there...
                for (Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.meta.Vtag>> e : augmentation.entrySet()) {
                    if (!e.getValue().equals(other.getAugmentation(e.getKey()))) {
                        return false;
                    }
                }
                // .. and give the other one the chance to do the same
                if (!obj.equals(this)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("Vtag [");
            boolean first = true;
        
            if (_resourceId != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_resourceId=");
                builder.append(_resourceId);
             }
            if (_tag != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_tag=");
                builder.append(_tag);
             }
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("augmentation=");
            builder.append(augmentation.values());
            return builder.append(']').toString();
        }
    }

}
