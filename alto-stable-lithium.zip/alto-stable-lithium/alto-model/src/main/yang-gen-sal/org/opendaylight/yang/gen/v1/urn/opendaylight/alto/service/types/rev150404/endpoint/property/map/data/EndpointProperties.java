package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.TypedEndpointAddress;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.EndpointPropertyMapData;
import java.util.List;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.endpoint.properties.Properties;
import org.opendaylight.yangtools.yang.binding.Augmentable;
import org.opendaylight.yangtools.yang.binding.Identifiable;


/**
 * EndpointPropertyMapData. Sec. 11.4.1.6. object-map { TypedEndpointAddr -&gt; 
 * EndpointProps; } EndpointPropertyMapData;
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service-types&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service-types.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * list endpoint-properties {
 *     key "endpoint"
 *     leaf endpoint {
 *         type typed-endpoint-address;
 *     }
 *     list properties {
 *         key "property-type"
 *         leaf property-type {
 *             type endpoint-property-type;
 *         }
 *         leaf property {
 *             type endpoint-property-value;
 *         }
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service-types/endpoint-property-map-data/endpoint-properties&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.EndpointPropertiesBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.EndpointPropertiesBuilder
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.EndpointPropertiesKey
 *
 */
public interface EndpointProperties
    extends
    ChildOf<EndpointPropertyMapData>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.EndpointProperties>,
    Identifiable<EndpointPropertiesKey>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto-service-types","2015-04-04","endpoint-properties"));

    TypedEndpointAddress getEndpoint();
    
    /**
     * EndpointProps. RFC7285 Sec. 11.4.1.6. object { EndpointPropertyType -&gt; 
     * JSONValue; } EndpointProps;
     *
     */
    List<Properties> getProperties();
    
    /**
     * Returns Primary Key of Yang List Type
     *
     */
    EndpointPropertiesKey getKey();

}

