package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.input;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.FilteredCostMapServiceInput;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * container cost-type {
 *     leaf cost-mode {
 *         type cost-mode;
 *     }
 *     leaf cost-metric {
 *         type cost-metric;
 *     }
 *     leaf description {
 *         type string;
 *     }
 *     uses cost-type;
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service/filtered-cost-map-service/input/cost-type&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.input.CostTypeBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.input.CostTypeBuilder
 *
 */
public interface CostType
    extends
    ChildOf<FilteredCostMapServiceInput>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.filtered.cost.map.service.input.CostType>,
    org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.CostType
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto","2015-04-04","cost-type"));


}

