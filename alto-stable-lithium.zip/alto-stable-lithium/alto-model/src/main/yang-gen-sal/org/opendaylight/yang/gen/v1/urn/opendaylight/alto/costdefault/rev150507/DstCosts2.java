package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507;
import org.opendaylight.yangtools.yang.binding.Augmentation;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.cost.map.map.DstCosts;
import org.opendaylight.yangtools.yang.binding.DataObject;


public interface DstCosts2
    extends
    DataObject,
    Augmentation<DstCosts>
{




    java.lang.String getCostDefault();

}

