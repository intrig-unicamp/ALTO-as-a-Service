package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.endpoint.properties;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.EndpointPropertyType;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.EndpointPropertyValue;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.EndpointProperties;
import org.opendaylight.yangtools.yang.binding.Augmentable;
import org.opendaylight.yangtools.yang.binding.Identifiable;


/**
 * EndpointProps. RFC7285 Sec. 11.4.1.6. object { EndpointPropertyType -&gt; 
 * JSONValue; } EndpointProps;
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service-types&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service-types.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * list properties {
 *     key "property-type"
 *     leaf property-type {
 *         type endpoint-property-type;
 *     }
 *     leaf property {
 *         type endpoint-property-value;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service-types/endpoint-property-map-data/endpoint-properties/properties&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.endpoint.properties.PropertiesBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.endpoint.properties.PropertiesBuilder
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.endpoint.properties.PropertiesKey
 *
 */
public interface Properties
    extends
    ChildOf<EndpointProperties>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.endpoint.property.map.data.endpoint.properties.Properties>,
    Identifiable<PropertiesKey>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto-service-types","2015-04-04","properties"));

    EndpointPropertyType getPropertyType();
    
    EndpointPropertyValue getProperty();
    
    /**
     * Returns Primary Key of Yang List Type
     *
     */
    PropertiesKey getKey();

}

