package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.EndpointPropertyMap;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.IRD;
import org.opendaylight.yangtools.yang.binding.Augmentable;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.NetworkMaps;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * container resources {
 *     container IRD {
 *         container meta {
 *             list cost-types {
 *                 key "cost-type-name"
 *                 leaf cost-type-name {
 *                     type cost-type-name;
 *                 }
 *                 leaf cost-mode {
 *                     type cost-mode;
 *                 }
 *                 leaf cost-metric {
 *                     type cost-metric;
 *                 }
 *                 leaf description {
 *                     type string;
 *                 }
 *                 uses cost-type;
 *             }
 *             container default-alto-network-map {
 *                 leaf resource-id {
 *                     type resource-id;
 *                 }
 *             }
 *             uses IRD-meta;
 *         }
 *         list resources {
 *             key "resource-id"
 *             leaf resource-id {
 *                 type resource-id;
 *             }
 *             leaf uri {
 *                 type uri;
 *             }
 *             leaf media-type {
 *                 type media-type;
 *             }
 *             leaf-list uses {
 *                 type resource-id;
 *             }
 *             leaf-list accepts {
 *                 type media-type;
 *             }
 *             container capabilities {
 *                 leaf cost-constraints {
 *                     type boolean;
 *                 }
 *                 leaf-list cost-type-names {
 *                     type cost-type-name;
 *                 }
 *                 leaf-list prop-types {
 *                     type endpoint-property-type;
 *                 }
 *             }
 *             uses uses;
 *             uses accepts;
 *             uses IRD-capabilities;
 *         }
 *         uses IRD;
 *     }
 *     container network-maps {
 *         list network-map {
 *             key "resource-id"
 *             leaf resource-id {
 *                 type resource-id;
 *             }
 *             leaf tag {
 *                 type tag-string;
 *             }
 *             list map {
 *                 key "pid"
 *                 leaf pid {
 *                     type pid-name;
 *                 }
 *                 list endpoint-address-group {
 *                     key "address-type"
 *                     leaf address-type {
 *                         type endpoint-address-type;
 *                     }
 *                     leaf-list endpoint-prefix {
 *                         type ip-prefix;
 *                     }
 *                 }
 *                 uses endpoint-address-group;
 *             }
 *             uses network-map;
 *         }
 *     }
 *     container cost-maps {
 *         list cost-map {
 *             key "resource-id"
 *             leaf resource-id {
 *                 type resource-id;
 *             }
 *             leaf tag {
 *                 type tag-string;
 *             }
 *             container meta {
 *                 list dependent-vtags {
 *                     key "resource-id"
 *                     leaf resource-id {
 *                         type resource-id;
 *                     }
 *                     leaf tag {
 *                         type tag-string;
 *                     }
 *                     uses vtag;
 *                 }
 *                 container cost-type {
 *                     leaf cost-mode {
 *                         type cost-mode;
 *                     }
 *                     leaf cost-metric {
 *                         type cost-metric;
 *                     }
 *                     leaf description {
 *                         type string;
 *                     }
 *                     uses cost-type;
 *                 }
 *                 uses cost-map-meta;
 *             }
 *             list map {
 *                 key "src"
 *                 leaf src {
 *                     type pid-name;
 *                 }
 *                 list dst-costs {
 *                     key "dst"
 *                     leaf dst {
 *                         type pid-name;
 *                     }
 *                     leaf cost-default {
 *                         type string;
 *                     }
 *                     augment \(urn:opendaylight:alto)resources\(urn:opendaylight:alto)cost-maps\(urn:opendaylight:alto)cost-map\(urn:opendaylight:alto)map\(urn:opendaylight:alto)dst-costs {
 *                         status CURRENT;
 *                         leaf cost-default {
 *                             type string;
 *                         }
 *                     }
 *                 }
 *             }
 *             uses cost-map;
 *         }
 *     }
 *     container endpoint-property-map {
 *         container meta {
 *             list dependent-vtags {
 *                 key "resource-id"
 *                 leaf resource-id {
 *                     type resource-id;
 *                 }
 *                 leaf tag {
 *                     type tag-string;
 *                 }
 *                 uses vtag;
 *             }
 *             uses endpoint-property-meta;
 *         }
 *         list endpoint-properties {
 *             key "endpoint"
 *             leaf endpoint {
 *                 type typed-endpoint-address;
 *             }
 *             list properties {
 *                 key "property-type"
 *                 leaf property-type {
 *                     type endpoint-property-type;
 *                 }
 *                 leaf property {
 *                     type endpoint-property-value;
 *                 }
 *             }
 *         }
 *         uses endpoint-property-map;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service/resources&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.ResourcesBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.ResourcesBuilder
 *
 */
public interface Resources
    extends
    ChildOf<AltoServiceData>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto","2015-04-04","resources"));

    IRD getIRD();
    
    NetworkMaps getNetworkMaps();
    
    CostMaps getCostMaps();
    
    EndpointPropertyMap getEndpointPropertyMap();

}

