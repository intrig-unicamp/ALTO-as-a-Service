package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yangtools.concepts.Builder;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts2} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts2
 *
 */
public class DstCosts2Builder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts2> {

    private java.lang.String _costDefault;


    public DstCosts2Builder() {
    }

    public DstCosts2Builder(DstCosts2 base) {
        this._costDefault = base.getCostDefault();
    }


    public java.lang.String getCostDefault() {
        return _costDefault;
    }

    public DstCosts2Builder setCostDefault(java.lang.String value) {
        this._costDefault = value;
        return this;
    }

    public DstCosts2 build() {
        return new DstCosts2Impl(this);
    }

    private static final class DstCosts2Impl implements DstCosts2 {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts2> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts2.class;
        }

        private final java.lang.String _costDefault;


        private DstCosts2Impl(DstCosts2Builder base) {
            this._costDefault = base.getCostDefault();
        }

        @Override
        public java.lang.String getCostDefault() {
            return _costDefault;
        }

        private int hash = 0;
        private volatile boolean hashValid = false;
        
        @Override
        public int hashCode() {
            if (hashValid) {
                return hash;
            }
        
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_costDefault == null) ? 0 : _costDefault.hashCode());
        
            hash = result;
            hashValid = true;
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts2.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts2 other = (org.opendaylight.yang.gen.v1.urn.opendaylight.alto.costdefault.rev150507.DstCosts2)obj;
            if (_costDefault == null) {
                if (other.getCostDefault() != null) {
                    return false;
                }
            } else if(!_costDefault.equals(other.getCostDefault())) {
                return false;
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("DstCosts2 [");
            boolean first = true;
        
            if (_costDefault != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_costDefault=");
                builder.append(_costDefault);
             }
            return builder.append(']').toString();
        }
    }

}
