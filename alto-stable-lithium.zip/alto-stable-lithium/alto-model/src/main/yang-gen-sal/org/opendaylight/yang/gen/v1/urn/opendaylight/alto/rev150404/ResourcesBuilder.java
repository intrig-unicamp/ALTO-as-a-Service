package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.EndpointPropertyMap;
import org.opendaylight.yangtools.yang.binding.Augmentation;
import org.opendaylight.yangtools.yang.binding.AugmentationHolder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.CostMaps;
import org.opendaylight.yangtools.yang.binding.DataObject;
import java.util.HashMap;
import org.opendaylight.yangtools.concepts.Builder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.IRD;
import java.util.Collections;
import java.util.Map;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.resources.NetworkMaps;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources
 *
 */
public class ResourcesBuilder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources> {

    private CostMaps _costMaps;
    private EndpointPropertyMap _endpointPropertyMap;
    private IRD _iRD;
    private NetworkMaps _networkMaps;

    Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>> augmentation = Collections.emptyMap();

    public ResourcesBuilder() {
    }

    public ResourcesBuilder(Resources base) {
        this._costMaps = base.getCostMaps();
        this._endpointPropertyMap = base.getEndpointPropertyMap();
        this._iRD = base.getIRD();
        this._networkMaps = base.getNetworkMaps();
        if (base instanceof ResourcesImpl) {
            ResourcesImpl impl = (ResourcesImpl) base;
            if (!impl.augmentation.isEmpty()) {
                this.augmentation = new HashMap<>(impl.augmentation);
            }
        } else if (base instanceof AugmentationHolder) {
            @SuppressWarnings("unchecked")
            AugmentationHolder<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources> casted =(AugmentationHolder<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>) base;
            if (!casted.augmentations().isEmpty()) {
                this.augmentation = new HashMap<>(casted.augmentations());
            }
        }
    }


    public CostMaps getCostMaps() {
        return _costMaps;
    }
    
    public EndpointPropertyMap getEndpointPropertyMap() {
        return _endpointPropertyMap;
    }
    
    public IRD getIRD() {
        return _iRD;
    }
    
    public NetworkMaps getNetworkMaps() {
        return _networkMaps;
    }
    
    @SuppressWarnings("unchecked")
    public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>> E getAugmentation(java.lang.Class<E> augmentationType) {
        if (augmentationType == null) {
            throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
        }
        return (E) augmentation.get(augmentationType);
    }

    public ResourcesBuilder setCostMaps(CostMaps value) {
        this._costMaps = value;
        return this;
    }
    
    public ResourcesBuilder setEndpointPropertyMap(EndpointPropertyMap value) {
        this._endpointPropertyMap = value;
        return this;
    }
    
    public ResourcesBuilder setIRD(IRD value) {
        this._iRD = value;
        return this;
    }
    
    public ResourcesBuilder setNetworkMaps(NetworkMaps value) {
        this._networkMaps = value;
        return this;
    }
    
    public ResourcesBuilder addAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>> augmentationType, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources> augmentation) {
        if (augmentation == null) {
            return removeAugmentation(augmentationType);
        }
    
        if (!(this.augmentation instanceof HashMap)) {
            this.augmentation = new HashMap<>();
        }
    
        this.augmentation.put(augmentationType, augmentation);
        return this;
    }
    
    public ResourcesBuilder removeAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>> augmentationType) {
        if (this.augmentation instanceof HashMap) {
            this.augmentation.remove(augmentationType);
        }
        return this;
    }

    public Resources build() {
        return new ResourcesImpl(this);
    }

    private static final class ResourcesImpl implements Resources {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources.class;
        }

        private final CostMaps _costMaps;
        private final EndpointPropertyMap _endpointPropertyMap;
        private final IRD _iRD;
        private final NetworkMaps _networkMaps;

        private Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>> augmentation = Collections.emptyMap();

        private ResourcesImpl(ResourcesBuilder base) {
            this._costMaps = base.getCostMaps();
            this._endpointPropertyMap = base.getEndpointPropertyMap();
            this._iRD = base.getIRD();
            this._networkMaps = base.getNetworkMaps();
            switch (base.augmentation.size()) {
            case 0:
                this.augmentation = Collections.emptyMap();
                break;
            case 1:
                final Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>> e = base.augmentation.entrySet().iterator().next();
                this.augmentation = Collections.<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>>singletonMap(e.getKey(), e.getValue());
                break;
            default :
                this.augmentation = new HashMap<>(base.augmentation);
            }
        }

        @Override
        public CostMaps getCostMaps() {
            return _costMaps;
        }
        
        @Override
        public EndpointPropertyMap getEndpointPropertyMap() {
            return _endpointPropertyMap;
        }
        
        @Override
        public IRD getIRD() {
            return _iRD;
        }
        
        @Override
        public NetworkMaps getNetworkMaps() {
            return _networkMaps;
        }
        
        @SuppressWarnings("unchecked")
        @Override
        public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>> E getAugmentation(java.lang.Class<E> augmentationType) {
            if (augmentationType == null) {
                throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
            }
            return (E) augmentation.get(augmentationType);
        }

        private int hash = 0;
        private volatile boolean hashValid = false;
        
        @Override
        public int hashCode() {
            if (hashValid) {
                return hash;
            }
        
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_costMaps == null) ? 0 : _costMaps.hashCode());
            result = prime * result + ((_endpointPropertyMap == null) ? 0 : _endpointPropertyMap.hashCode());
            result = prime * result + ((_iRD == null) ? 0 : _iRD.hashCode());
            result = prime * result + ((_networkMaps == null) ? 0 : _networkMaps.hashCode());
            result = prime * result + ((augmentation == null) ? 0 : augmentation.hashCode());
        
            hash = result;
            hashValid = true;
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources other = (org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources)obj;
            if (_costMaps == null) {
                if (other.getCostMaps() != null) {
                    return false;
                }
            } else if(!_costMaps.equals(other.getCostMaps())) {
                return false;
            }
            if (_endpointPropertyMap == null) {
                if (other.getEndpointPropertyMap() != null) {
                    return false;
                }
            } else if(!_endpointPropertyMap.equals(other.getEndpointPropertyMap())) {
                return false;
            }
            if (_iRD == null) {
                if (other.getIRD() != null) {
                    return false;
                }
            } else if(!_iRD.equals(other.getIRD())) {
                return false;
            }
            if (_networkMaps == null) {
                if (other.getNetworkMaps() != null) {
                    return false;
                }
            } else if(!_networkMaps.equals(other.getNetworkMaps())) {
                return false;
            }
            if (getClass() == obj.getClass()) {
                // Simple case: we are comparing against self
                ResourcesImpl otherImpl = (ResourcesImpl) obj;
                if (augmentation == null) {
                    if (otherImpl.augmentation != null) {
                        return false;
                    }
                } else if(!augmentation.equals(otherImpl.augmentation)) {
                    return false;
                }
            } else {
                // Hard case: compare our augments with presence there...
                for (Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.rev150404.Resources>> e : augmentation.entrySet()) {
                    if (!e.getValue().equals(other.getAugmentation(e.getKey()))) {
                        return false;
                    }
                }
                // .. and give the other one the chance to do the same
                if (!obj.equals(this)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("Resources [");
            boolean first = true;
        
            if (_costMaps != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_costMaps=");
                builder.append(_costMaps);
             }
            if (_endpointPropertyMap != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_endpointPropertyMap=");
                builder.append(_endpointPropertyMap);
             }
            if (_iRD != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_iRD=");
                builder.append(_iRD);
             }
            if (_networkMaps != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_networkMaps=");
                builder.append(_networkMaps);
             }
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("augmentation=");
            builder.append(augmentation.values());
            return builder.append(']').toString();
        }
    }

}
