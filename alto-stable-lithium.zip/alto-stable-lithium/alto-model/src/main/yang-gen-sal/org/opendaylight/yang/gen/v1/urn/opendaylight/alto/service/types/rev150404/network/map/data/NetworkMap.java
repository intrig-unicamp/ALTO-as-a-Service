package org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.data;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.PidName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.EndpointAddressGroup;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.NetworkMapData;
import org.opendaylight.yangtools.yang.binding.Augmentable;
import org.opendaylight.yangtools.yang.binding.Identifiable;


/**
 * RFC7285 Sec. 11.2.1.6. object-map { PIDName -&gt; EndpointAddrGroup; } 
 * NetworkMapData;
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;alto-service-types&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/alto-service-types.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * list network-map {
 *     key "pid"
 *     leaf pid {
 *         type pid-name;
 *     }
 *     list endpoint-address-group {
 *         key "address-type"
 *         leaf address-type {
 *             type endpoint-address-type;
 *         }
 *         leaf-list endpoint-prefix {
 *             type ip-prefix;
 *         }
 *     }
 *     uses endpoint-address-group;
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;alto-service-types/network-map-data/network-map&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.data.NetworkMapBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.data.NetworkMapBuilder
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.data.NetworkMapKey
 *
 */
public interface NetworkMap
    extends
    ChildOf<NetworkMapData>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.network.map.data.NetworkMap>,
    EndpointAddressGroup,
    Identifiable<NetworkMapKey>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:alto-service-types","2015-04-04","network-map"));

    PidName getPid();
    
    /**
     * Returns Primary Key of Yang List Type
     *
     */
    NetworkMapKey getKey();

}

