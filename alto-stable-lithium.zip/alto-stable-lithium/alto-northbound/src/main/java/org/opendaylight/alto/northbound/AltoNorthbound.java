/*
 * Copyright (c) 2015 Yale University and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.opendaylight.alto.northbound;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.opendaylight.alto.commons.types.rfc7285.RFC7285JSONMapper;
import org.opendaylight.alto.commons.types.rfc7285.FormatValidator;
import org.opendaylight.alto.commons.types.rfc7285.MediaType;
import org.opendaylight.alto.commons.types.rfc7285.RFC7285NetworkMap;
import org.opendaylight.alto.commons.types.rfc7285.RFC7285CostType;
import org.opendaylight.alto.commons.types.rfc7285.RFC7285IRD;
import org.opendaylight.alto.commons.types.rfc7285.RFC7285VersionTag;
import org.opendaylight.alto.commons.types.rfc7285.RFC7285CostMap;
import org.opendaylight.alto.commons.types.rfc7285.RFC7285Endpoint;
import org.opendaylight.alto.services.api.rfc7285.AltoService;
import org.opendaylight.alto.services.api.rfc7285.IRDService;
import org.opendaylight.alto.services.api.rfc7285.NetworkMapService;
import org.opendaylight.alto.services.api.rfc7285.CostMapService;
import org.opendaylight.alto.services.api.rfc7285.EndpointCostService;
import org.opendaylight.alto.services.api.rfc7285.EndpointPropertyService;
import org.opendaylight.alto.northbound.exception.AltoBasicException;
import org.opendaylight.alto.northbound.exception.AltoBadFormatException;
import org.opendaylight.controller.sal.utils.ServiceHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.opendaylight.yang.gen.v1.urn.opendaylight.alto.service.types.rev150404.CostMode;

@Path("/")
public class AltoNorthbound {

    private static final Logger logger = LoggerFactory
            .getLogger(AltoNorthbound.class);

    private RFC7285JSONMapper mapper = new RFC7285JSONMapper();

    private static final String SERVER_ROOT_URI = "http://192.168.122.1:7474/db/data/";
    private static final String SERVER_AS_TOPOLOGY = "http://192.168.56.102:7474/db/data/";
    public static JsonNode jsonResult;
    private static final String IPv4 = "ipv4";
    private static final String IPv6 = "ipv6";

    private static final String[] lstIXP20141208 = { "BA", "BEL", "CAS", "CE",
            "CGB", "CPV", "CXJ", "DF", "GYN", "LAJ", "LDA", "MAO", "MG", "MGF",
            "NAT", "PE", "PR", "RJ", "RS", "SC", "SCA", "SJC", "SJP", "SP",
            "VIX"};
    // private static final String[] lstIXP20141208 = { "TEST" };
    private static final String strPTTaux = "20121:26121:";

    private <E> E getService(Class<E> clazz) {
        E service = (E) ServiceHelper.getGlobalInstance(clazz, this);
        if (service == null) {
            service = (E) ServiceHelper.getGlobalInstance(AltoService.class,
                    this);
        }
        return service;
    }

    private void checkService(Object service) throws Exception {
        if (service == null)
            throw new AltoBasicException(Status.SERVICE_UNAVAILABLE, null);
    }

    private void checkResourceId(String rid) throws AltoBadFormatException {
        if (!FormatValidator.validResourceId(rid))
            throw new AltoBadFormatException("resource-id", rid);
    }

    private void checkTag(String tag) throws AltoBadFormatException {
        if (!FormatValidator.validTag(tag))
            throw new AltoBadFormatException("tag", tag);
    }

    private Response fail(Response.Status status, Object data) {
        try {
            String output = (data == null ? "" : mapper.asJSON(data));
            return Response.status(status).entity(output)
                    .type(MediaType.ALTO_ERROR).build();
        } catch (Exception e) {
            logger.error("Failed to parse object to json: {}", data.toString());
            return Response.status(status).type(MediaType.ALTO_ERROR).build();
        }
    }

    private Response success(Object data, String mediaType) {
        try {
            String output = mapper.asJSON(data);
            return Response.ok(output, mediaType).build();
        } catch (Exception e) {
            logger.error("Failed to parse object to json: {}", data.toString());
            return fail(Status.INTERNAL_SERVER_ERROR, null);
        }
    }

    @GET
    @Produces({ MediaType.ALTO_DIRECTORY, MediaType.ALTO_ERROR })
    public Response retrieveIRD() throws Exception {
        IRDService service = getService(IRDService.class);
        checkService(service);

        RFC7285IRD ird = service.getDefaultIRD();
        if (ird == null)
            return fail(Status.NOT_FOUND, null);
        return success(ird, MediaType.ALTO_DIRECTORY);
    }

    @Path("/ird/{id}")
    @GET
    @Produces({ MediaType.ALTO_DIRECTORY, MediaType.ALTO_ERROR })
    public Response retrieveIRD(@PathParam("id") String id) throws Exception {
        IRDService service = getService(IRDService.class);
        checkService(service);
        checkResourceId(id);

        RFC7285IRD ird = service.getIRD(id);
        if (ird == null)
            return fail(Status.NOT_FOUND, id);
        return success(ird, MediaType.ALTO_DIRECTORY);
    }

    @Path("/networkmap")
    @GET
    @Produces({ MediaType.ALTO_NETWORKMAP, MediaType.ALTO_ERROR })
    public Response retrieveDefaultNetworkMap() throws Exception {
        NetworkMapService service = getService(NetworkMapService.class);
        checkService(service);

        RFC7285NetworkMap map = service.getDefaultNetworkMap();
        if (map == null)
            return fail(Status.NOT_FOUND, null);
        return success(map, MediaType.ALTO_NETWORKMAP);
    }

    @Path("/networkmap/{id}")
    @GET
    @Produces({ MediaType.ALTO_NETWORKMAP, MediaType.ALTO_ERROR })
    public Response retrieveNetworkMap(@PathParam("id") String id)
            throws Exception {
        NetworkMapService service = getService(NetworkMapService.class);
        checkService(service);
        checkResourceId(id);

        RFC7285NetworkMap map = service.getNetworkMap(id);
        if (map == null)
            return fail(Status.NOT_FOUND, id);
        return success(map, MediaType.ALTO_NETWORKMAP);
    }

    @Path("/networkmap/{id}/{tag}")
    @GET
    @Produces({ MediaType.ALTO_NETWORKMAP, MediaType.ALTO_ERROR })
    public Response retrieveNetworkMap(@PathParam("id") String id,
            @PathParam("tag") String tag) throws Exception {
        NetworkMapService service = getService(NetworkMapService.class);
        checkService(service);
        checkResourceId(id);
        checkTag(tag);

        RFC7285VersionTag vtag = new RFC7285VersionTag(id, tag);
        RFC7285NetworkMap map = service.getNetworkMap(vtag);
        if (map == null)
            return fail(Status.NOT_FOUND, vtag);
        return success(map, MediaType.ALTO_NETWORKMAP);
    }

    @Path("/costmap/{id}")
    @GET
    @Produces({ MediaType.ALTO_COSTMAP, MediaType.ALTO_ERROR })
    public Response retrieveCostMap(@PathParam("id") String id)
            throws Exception {
        CostMapService service = getService(CostMapService.class);
        checkService(service);
        checkResourceId(id);

        RFC7285CostMap map = service.getCostMap(id);
        if (map == null)
            return fail(Status.NOT_FOUND, id);
        return success(map, MediaType.ALTO_COSTMAP);
    }

    @Path("/costmap/{id}/{tag}")
    @GET
    @Produces({ MediaType.ALTO_COSTMAP, MediaType.ALTO_ERROR })
    public Response retrieveCostMap(@PathParam("id") String id,
            @PathParam("tag") String tag) throws Exception {
        CostMapService service = getService(CostMapService.class);
        checkService(service);
        checkResourceId(id);
        checkTag(tag);

        RFC7285VersionTag vtag = new RFC7285VersionTag(id, tag);
        RFC7285CostMap map = service.getCostMap(vtag);
        if (map == null)
            return fail(Status.NOT_FOUND, vtag);
        return success(map, MediaType.ALTO_COSTMAP);
    }

    @Path("/costmap/{id}/{mode}/{metric}")
    @GET
    @Produces({ MediaType.ALTO_COSTMAP, MediaType.ALTO_ERROR })
    public Response retrieveCostMap(@PathParam("id") String id,
            @PathParam("mode") String mode, @PathParam("metric") String metric)
            throws Exception {
        CostMapService service = getService(CostMapService.class);
        checkService(service);
        checkResourceId(id);

        RFC7285CostType costType = new RFC7285CostType(mode, metric);
        if (!service.supportCostType(id, costType))
            return fail(Status.NOT_FOUND, costType);
        RFC7285CostMap map = service.getCostMap(id, costType);
        if (map == null)
            return fail(Status.NOT_FOUND, id);
        return success(map, MediaType.ALTO_COSTMAP);
    }

    @Path("/costmap/{id}/{tag}/{mode}/{metric}")
    @GET
    @Produces({ MediaType.ALTO_COSTMAP, MediaType.ALTO_ERROR })
    public Response retrieveCostMap(@PathParam("id") String id,
            @PathParam("tag") String tag, @PathParam("mode") String mode,
            @PathParam("metric") String metric) throws Exception {
        CostMapService service = getService(CostMapService.class);
        checkService(service);
        checkResourceId(id);
        checkTag(tag);

        RFC7285VersionTag vtag = new RFC7285VersionTag(id, tag);
        RFC7285CostType costType = new RFC7285CostType(mode, metric);
        if (!service.supportCostType(vtag, costType))
            return fail(Status.NOT_FOUND, costType);
        RFC7285CostMap map = service.getCostMap(vtag, costType);
        if (map == null)
            return fail(Status.NOT_FOUND, vtag);
        return success(map, MediaType.ALTO_COSTMAP);
    }

    @Path("/filtered/networkmap/{id}")
    @POST
    @Consumes({ MediaType.ALTO_NETWORKMAP_FILTER })
    @Produces({ MediaType.ALTO_NETWORKMAP, MediaType.ALTO_ERROR })
    public Response retrieveFilteredNetworkMap(@PathParam("id") String id,
            String filterJSON) throws Exception {
        // NetworkMapService service = getService(NetworkMapService.class);
        // checkService(service);
        // checkResourceId(id);

        // RFC7285NetworkMap.Filter filter =
        // mapper.asNetworkMapFilter(filterJSON);

        // if (!service.validateNetworkMapFilter(id, filter))
        // return fail(Status.BAD_REQUEST, filter);
        // RFC7285NetworkMap map = service.getNetworkMap(id, filter);

        RFC7285NetworkMap.Filter filter = mapper.asNetworkMapFilter(filterJSON);
        String lstPID = "";
        for (String sAux : filter.pids)
            lstPID = lstPID + "'" + sAux + "',";
        lstPID = lstPID.substring(0, lstPID.length() - 1);

        String strQuery = "";
        strQuery = String
                .format(new StringBuilder()
                        .append("MATCH (v:VersionTag {ResourceID:'%s'})-[r:Has_PID]->(pid)")
                        .append(" WHERE pid.Name IN [%s]")
                        .append(" OPTIONAL MATCH (pid)-[e:Has_EndPoint]->")
                        .append("(p)<-[r2:Type_EndPoint]-(type)")
                        .append(" WITH v.Tag AS Tag,pid.Name AS Name,")
                        .append(" COLLECT([type.Type,p.Prefix]) AS p")
                        .append(" RETURN Tag, Name,")
                        .append(" [prefix IN FILTER(pAux in p where pAux[0]='%s') | prefix[1]] AS IPv4,")
                        .append(" [prefix in FILTER(pAux IN p where pAux[0]='%s') | prefix[1]] AS IPv6")
                        .append(" ORDER BY Name").toString(), id, lstPID, IPv4,
                        IPv6);
        REST_Query(strQuery, SERVER_ROOT_URI);

        Iterator<JsonNode> queryNeo4j = jsonResult.path("results")
                .findPath("data").elements();

        RFC7285NetworkMap map = null;
        if (queryNeo4j.hasNext()) {
            map = new RFC7285NetworkMap();

            Iterator<JsonNode> lstQuery = queryNeo4j.next().path("row")
                    .elements();
            RFC7285NetworkMap.Meta meta = new RFC7285NetworkMap.Meta();
            meta.vtag = new RFC7285VersionTag(id, lstQuery.next().asText());

            Map<String, RFC7285Endpoint.AddressGroup> AuxMap = new LinkedHashMap<String, RFC7285Endpoint.AddressGroup>();
            RFC7285Endpoint.AddressGroup ag = new RFC7285Endpoint.AddressGroup();
            String strPID = lstQuery.next().asText();

            List<String> lstIPv4 = createIPList(lstQuery.next().elements());
            List<String> lstIPv6 = createIPList(lstQuery.next().elements());
            if (lstIPv4.size() > 0)
                ag.ipv4 = lstIPv4;
            if (lstIPv6.size() > 0)
                ag.ipv6 = lstIPv6;

            AuxMap.put(strPID, ag);

            while (queryNeo4j.hasNext()) {
                lstQuery = queryNeo4j.next().path("row").elements();

                lstQuery.next();
                ag = new RFC7285Endpoint.AddressGroup();
                strPID = lstQuery.next().asText();

                lstIPv4 = createIPList(lstQuery.next().elements());
                lstIPv6 = createIPList(lstQuery.next().elements());
                if (lstIPv4.size() > 0)
                    ag.ipv4 = lstIPv4;
                if (lstIPv6.size() > 0)
                    ag.ipv6 = lstIPv6;

                AuxMap.put(strPID, ag);
            }

            map.meta = meta;
            map.map = AuxMap;
        }

        if (map == null)
            return fail(Status.NOT_FOUND, id);
        return success(map, MediaType.ALTO_NETWORKMAP);
    }

    @Path("/filtered/networkmap/{id}/{tag}")
    @POST
    @Consumes({ MediaType.ALTO_NETWORKMAP_FILTER })
    @Produces({ MediaType.ALTO_NETWORKMAP, MediaType.ALTO_ERROR })
    public Response retrieveFilteredNetworkMap(@PathParam("id") String id,
            @PathParam("tag") String tag, String filterJSON) throws Exception {
        NetworkMapService service = getService(NetworkMapService.class);
        checkService(service);
        checkResourceId(id);
        checkTag(tag);

        RFC7285VersionTag vtag = new RFC7285VersionTag(id, tag);
        RFC7285NetworkMap.Filter filter = mapper.asNetworkMapFilter(filterJSON);
        if (!service.validateNetworkMapFilter(vtag, filter))
            return fail(Status.BAD_REQUEST, filter);

        RFC7285NetworkMap map = service.getNetworkMap(vtag, filter);
        if (map == null)
            return fail(Status.NOT_FOUND, vtag);
        return success(map, MediaType.ALTO_NETWORKMAP);
    }

    @Path("/filtered/costmap/{id}")
    @POST
    @Consumes({ MediaType.ALTO_COSTMAP_FILTER })
    @Produces({ MediaType.ALTO_COSTMAP, MediaType.ALTO_ERROR })
    public Response retrieveFilteredCostMap(@PathParam("id") String id,
            String filterJSON) throws Exception {
        // CostMapService service = getService(CostMapService.class);
        // checkService(service);
        // checkResourceId(id);

        // RFC7285CostMap.Filter filter = mapper.asCostMapFilter(filterJSON);
        // if (!service.validateCostMapFilter(id, filter))
        // return fail(Status.BAD_REQUEST, filter);

        // RFC7285CostMap map = service.getCostMap(id, filter);

        RFC7285CostMap.Filter filter = mapper.asCostMapFilter(filterJSON);
        String strMode = filter.costType.mode;
        String strMetric = filter.costType.metric;
        String strSRC = "";
        for (String sAux : filter.pids.src)
            strSRC = strSRC + "'" + sAux + "',";
        strSRC = strSRC.substring(0, strSRC.length() - 1);
        String strDST = "";
        for (String sAux : filter.pids.dst)
            strDST = strDST + "'" + sAux + "',";
        strDST = strDST.substring(0, strDST.length() - 1);

        String strQuery = "";
        // Numerical(0);
        // Ordinal(1)
        if (strMode.equals(CostMode.forValue(0).toString())) {
            strQuery = String
                    .format(new StringBuilder()
                            .append("MATCH (v:VersionTag {ResourceID:'%s'})-[r:Has_PID]->(s)")
                            .append(" WHERE s.Name IN [%s]")
                            .append(" OPTIONAL MATCH (s)-[c:Cost]->(d)")
                            .append(" WHERE d.Name IN [%s]")
                            .append(" WITH v.ResourceID AS ResourceID, v.Tag AS Tag,")
                            .append(" s.Name AS PIDsrc, d.Name AS PIDdst, c.%s AS hops")
                            .append(" ORDER BY PIDsrc, hops, PIDdst")
                            .append(" return ResourceID, Tag, PIDsrc, collect([PIDdst, hops])")
                            .toString(), id, strSRC, strDST, strMetric);
        } else {
            if (strMode.equals(CostMode.forValue(1).toString()))
                System.out.println("");
        }

        REST_Query(strQuery, SERVER_ROOT_URI);

        Iterator<JsonNode> queryNeo4j = jsonResult.path("results")
                .findPath("data").elements();

        RFC7285CostMap map = createCostMapResult(queryNeo4j, strMode,
                strMetric, strDST);

        if (map == null)
            return fail(Status.NOT_FOUND, id);
        return success(map, MediaType.ALTO_COSTMAP);
    }

    @Path("/filtered/costmap/{id}/{tag}")
    @POST
    @Consumes({ MediaType.ALTO_COSTMAP_FILTER })
    @Produces({ MediaType.ALTO_COSTMAP, MediaType.ALTO_ERROR })
    public Response retrieveFilteredCostMap(@PathParam("id") String id,
            @PathParam("tag") String tag, String filterJSON) throws Exception {
        CostMapService service = getService(CostMapService.class);
        checkService(service);
        checkResourceId(id);
        checkTag(tag);

        RFC7285VersionTag vtag = new RFC7285VersionTag(id, tag);
        RFC7285CostMap.Filter filter = mapper.asCostMapFilter(filterJSON);
        if (!service.validateCostMapFilter(vtag, filter))
            return fail(Status.BAD_REQUEST, filter);

        RFC7285CostMap map = service.getCostMap(vtag, filter);
        if (map == null)
            return fail(Status.NOT_FOUND, vtag);
        return success(map, MediaType.ALTO_COSTMAP);
    }

    @Path("/endpointprop/lookup/{id}")
    @POST
    @Consumes({ MediaType.ALTO_ENDPOINT_PROPPARAMS })
    @Produces({ MediaType.ALTO_ENDPOINT_PROP, MediaType.ALTO_ERROR })
    public Response retrieveEndpointPropMap(@PathParam("id") String id,
            String params) throws Exception {
        EndpointPropertyService service = getService(EndpointPropertyService.class);
        checkService(service);
        checkResourceId(id);

        RFC7285Endpoint.PropertyRequest request = mapper
                .asPropertyRequest(params);
        RFC7285Endpoint.PropertyResponse response = service
                .getEndpointProperty(id, request);
        if (response == null)
            return fail(Status.NOT_FOUND, request);
        return success(response, MediaType.ALTO_ENDPOINT_PROP);
    }

    @Path("/endpointprop/lookup/{id}/{tag}")
    @POST
    @Consumes({ MediaType.ALTO_ENDPOINT_PROPPARAMS })
    @Produces({ MediaType.ALTO_ENDPOINT_PROP, MediaType.ALTO_ERROR })
    public Response retrieveEndpointPropMap(@PathParam("id") String id,
            @PathParam("tag") String tag, String params) throws Exception {
        EndpointPropertyService service = getService(EndpointPropertyService.class);
        checkService(service);
        checkResourceId(id);
        checkTag(tag);

        RFC7285VersionTag vtag = new RFC7285VersionTag(id, tag);
        RFC7285Endpoint.PropertyRequest request = mapper
                .asPropertyRequest(params);
        RFC7285Endpoint.PropertyResponse response = service
                .getEndpointProperty(vtag, request);
        if (response == null)
            return fail(Status.NOT_FOUND, request);
        return success(response, MediaType.ALTO_ENDPOINT_PROP);
    }

    @Path("/endpointcost/lookup/{id}")
    @POST
    @Consumes({ MediaType.ALTO_ENDPOINT_COSTPARAMS })
    @Produces({ MediaType.ALTO_ENDPOINT_COST, MediaType.ALTO_ERROR })
    public Response retrieveEndpointCostMap(@PathParam("id") String id,
            String params) throws Exception {
        EndpointCostService service = getService(EndpointCostService.class);
        checkService(service);
        checkResourceId(id);

        RFC7285Endpoint.CostRequest request = mapper.asCostRequest(params);
        RFC7285Endpoint.CostResponse response = service.getEndpointCost(id,
                request);
        if (response == null)
            return fail(Status.NOT_FOUND, request);
        return success(response, MediaType.ALTO_ENDPOINT_COST);
    }

    @Path("/endpointcost/lookup/{id}/{tag}")
    @POST
    @Consumes({ MediaType.ALTO_ENDPOINT_COSTPARAMS })
    @Produces({ MediaType.ALTO_ENDPOINT_COST, MediaType.ALTO_ERROR })
    public Response retrieveEndpointCostMap(@PathParam("id") String id,
            @PathParam("tag") String tag, String params) throws Exception {
        EndpointCostService service = getService(EndpointCostService.class);
        checkService(service);
        checkResourceId(id);
        checkTag(tag);

        RFC7285VersionTag vtag = new RFC7285VersionTag(id, tag);
        RFC7285Endpoint.CostRequest request = mapper.asCostRequest(params);
        RFC7285Endpoint.CostResponse response = service.getEndpointCost(vtag,
                request);
        if (response == null)
            return fail(Status.NOT_FOUND, request);
        return success(response, MediaType.ALTO_ENDPOINT_COST);
    }

    // /////////////////////////////////////////////////////////////

    private RFC7285CostMap createCostMapResult(Iterator<JsonNode> queryNeo4j,
            String strMode, String strMetric, String strDST) throws Exception {
        RFC7285CostMap map;

        if (queryNeo4j.hasNext()) {

            map = new RFC7285CostMap();
            Iterator<JsonNode> lstQuery = queryNeo4j.next().path("row")
                    .elements();

            RFC7285CostMap.Meta meta = new RFC7285CostMap.Meta();
            meta.costType = new RFC7285CostType(strMode, strMetric);
            List<RFC7285VersionTag> netmap_tags = new LinkedList<RFC7285VersionTag>();
            netmap_tags.add(new RFC7285VersionTag(lstQuery.next().asText(),
                    lstQuery.next().asText()));
            meta.netmap_tags = netmap_tags;

            String PIDsrc = lstQuery.next().asText();
            Map<String, Map<String, Object>> AuxMap = new LinkedHashMap<String, Map<String, Object>>();
            Map<String, Object> mapDST = createPIDdst(lstQuery.next()
                    .elements(), PIDsrc, strDST, strMetric);

            AuxMap.put(PIDsrc, mapDST);

            while (queryNeo4j.hasNext()) {
                lstQuery = queryNeo4j.next().path("row").elements();

                lstQuery.next();
                lstQuery.next();

                PIDsrc = lstQuery.next().asText();
                mapDST = createPIDdst(lstQuery.next().elements(), PIDsrc,
                        strDST, strMetric);

                AuxMap.put(PIDsrc, mapDST);
            }

            map.meta = meta;
            map.map = AuxMap;

            return map;
        }

        return null;
    }

    private Map<String, Object> createPIDdst(Iterator<JsonNode> PIDdst,
            String PIDsrc, String strDST, String strMetric) throws Exception {
        Map<String, Object> mapDST = new LinkedHashMap<String, Object>();
        String strDSTAux = strDST;

        while (PIDdst.hasNext()) {
            Iterator<JsonNode> cost = PIDdst.next().elements();
            String PID = cost.next().toString().replaceAll("\"", "");
            String costValue = cost.next().toString();
            if (!PID.equals("null") && !costValue.equals("null")) {
                mapDST.put(PID, Integer.parseInt(costValue));
                strDSTAux = strDSTAux.replace("'" + PID + "'", "");
            }
        }

        int intAShops = 0;
        String strQuery;

        if (mapDST.size() < strDST.split(",").length) {
            strDSTAux = strDSTAux.replace("'", "");
            strDSTAux = strDSTAux.replace(",,", ",");

            for (String strPIDdst : strDSTAux.split(",")) {
                if (!strPIDdst.isEmpty()) {
                    if (!PIDsrc.equals(strPIDdst)) {
                        strQuery = strQueryCost(strMetric, PIDsrc, strPIDdst);

                        REST_Query(strQuery, SERVER_AS_TOPOLOGY);
                        Iterator<JsonNode> ite = jsonResult.path("results")
                                .findPath("data").elements();
                        if (ite.hasNext()) {
                            while (ite.hasNext()) {
                                JsonNode temp = ite.next().path("row");
                                Iterator<JsonNode> ite1 = temp.elements();
                                ite1.next();
                                intAShops = ite1.next().asInt();
                            }
                        } else
                            intAShops = -1;
                    } else
                        intAShops = 0;

                    if (intAShops > -1) {
                        strQuery = String
                                .format(new StringBuilder()
                                        .append("MATCH (startAS:PID {Name:'%s'}),")
                                        .append("(endAS:PID {Name:'%s'})")
                                        .append(" MERGE (startAS)-[c:Cost]->(endAS)")
                                        .append(" SET c.%s = %d").toString(),
                                        PIDsrc, strPIDdst, strMetric, intAShops);

                        REST_Query(strQuery, SERVER_ROOT_URI);

                        mapDST.put(strPIDdst, intAShops);
                    }
                }
            }
        }

        return mapDST;
    }

    private String strQueryCost(String strMetric, String PIDsrc,
            String strPIDdst) {
        String strQuery = "";
        switch (strMetric) {
        case "HopsNumber":
            strQuery = String
                    .format(new StringBuilder()
                            .append("MATCH p=shortestPath((startAS:AS {number:'%s'})")
                            .append("-[r:LINK*]-(endAS:AS {number:'%s'}))")
                            .append(" WITH extract(n in nodes(p) | n.number) as path")
                            .append(",reduce(s=0, rel IN r | s+1) as depth")
                            .append(" RETURN path, depth").toString(),
                            PIDsrc.replace("AS", ""),
                            strPIDdst.replace("AS", ""));
            break;
        case "HopsNumberPTT":
            String strPTT = "";
            for (String strIXP : lstIXP20141208) {
                strPTT = strPTT + "'" + strPTTaux + strIXP + "',";
            }
            strPTT = strPTT.substring(0, strPTT.length() - 1);

            strQuery = String
                    .format(new StringBuilder()
                            .append("MATCH p=shortestPath((startAS:AS {number:'%s'})")
                            .append("-[r:LINK*]-(endAS:AS {number:'%s'}))")
                            .append(" WITH extract(n in nodes(p) | n.number) AS path")
                            .append(",REDUCE(s=0, rel IN r | s+1) AS depth")
                            .append(",REDUCE(NroPTT=0, ptt in nodes(p) | CASE WHEN ptt.number IN [%s] THEN NroPTT+1 ELSE NroPTT END) AS ptt")
                            .append(" RETURN path, depth - (2*ptt) AS depth")
                            .toString(), PIDsrc.replace("AS", ""),
                            strPIDdst.replace("AS", ""), strPTT);
            break;

        }
        return strQuery;
    }

    private List<String> createIPList(Iterator<JsonNode> lstIp) {
        List<String> lstIP = new ArrayList<String>();
        while (lstIp.hasNext())
            lstIP.add(lstIp.next().toString().replaceAll("\"", ""));

        return lstIP;
    }

    private static long REST_Query(String query, String strSERVER)
            throws Exception {

        // System.out.println("Query " + query);

        // START SNIPPET: queryAllNodes
        final String txUri = strSERVER + "transaction/commit";
        WebResource resource = Client.create().resource(txUri);

        String payload = "{\"statements\" : [ {\"statement\" : \"" + query
                + "\"} ]}";

        long startTimeNeo4j = System.currentTimeMillis();
        ClientResponse response = resource.accept("application/json")
                .type("application/json").entity(payload)
                .post(ClientResponse.class);
        long endTimeNeo4j = System.currentTimeMillis();

        jsonResult = new ObjectMapper().readTree(response
                .getEntity(String.class));

        response.close();

        return endTimeNeo4j - startTimeNeo4j;
    }
}