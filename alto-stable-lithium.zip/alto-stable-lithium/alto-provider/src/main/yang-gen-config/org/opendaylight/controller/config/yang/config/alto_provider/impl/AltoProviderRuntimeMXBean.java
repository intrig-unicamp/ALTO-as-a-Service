package org.opendaylight.controller.config.yang.config.alto_provider.impl;
public interface AltoProviderRuntimeMXBean extends org.opendaylight.controller.config.api.runtime.RuntimeBean {

}
